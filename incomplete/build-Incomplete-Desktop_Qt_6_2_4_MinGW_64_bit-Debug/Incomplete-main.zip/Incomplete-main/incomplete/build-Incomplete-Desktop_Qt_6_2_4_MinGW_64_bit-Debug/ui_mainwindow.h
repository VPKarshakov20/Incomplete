/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *cardbase1;
    QLabel *cardbase2;
    QLabel *cardbase3;
    QLabel *cardbase4;
    QLabel *cardbase5;
    QLabel *cardbase6;
    QLabel *uprow;
    QLabel *uprow_2;
    QLabel *uprow_3;
    QLabel *uprow_4;
    QLabel *uprow_5;
    QLabel *uprow2;
    QLabel *uprow2_2;
    QLabel *uprow2_3;
    QLabel *uprow2_4;
    QLabel *uprow3;
    QLabel *uprow3_2;
    QLabel *uprow3_3;
    QLabel *uprow4;
    QLabel *uprow4_2;
    QLabel *uprow5;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1209, 629);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(970, 70, 161, 191));
        label->setPixmap(QPixmap(QString::fromUtf8("../../card.png")));
        label->setScaledContents(true);
        cardbase1 = new QLabel(centralwidget);
        cardbase1->setObjectName(QString::fromUtf8("cardbase1"));
        cardbase1->setGeometry(QRect(20, 310, 41, 60));
        cardbase1->setPixmap(QPixmap(QString::fromUtf8("../../01 card.png")));
        cardbase1->setScaledContents(true);
        cardbase2 = new QLabel(centralwidget);
        cardbase2->setObjectName(QString::fromUtf8("cardbase2"));
        cardbase2->setGeometry(QRect(60, 310, 41, 60));
        cardbase2->setPixmap(QPixmap(QString::fromUtf8("../../01 card flipped.png")));
        cardbase2->setScaledContents(true);
        cardbase3 = new QLabel(centralwidget);
        cardbase3->setObjectName(QString::fromUtf8("cardbase3"));
        cardbase3->setGeometry(QRect(100, 310, 41, 60));
        cardbase3->setPixmap(QPixmap(QString::fromUtf8("../../01 card.png")));
        cardbase3->setScaledContents(true);
        cardbase4 = new QLabel(centralwidget);
        cardbase4->setObjectName(QString::fromUtf8("cardbase4"));
        cardbase4->setGeometry(QRect(140, 310, 41, 60));
        cardbase4->setPixmap(QPixmap(QString::fromUtf8("../../01 card.png")));
        cardbase4->setScaledContents(true);
        cardbase5 = new QLabel(centralwidget);
        cardbase5->setObjectName(QString::fromUtf8("cardbase5"));
        cardbase5->setGeometry(QRect(180, 310, 40, 60));
        cardbase5->setPixmap(QPixmap(QString::fromUtf8("../../01 card.png")));
        cardbase5->setScaledContents(true);
        cardbase6 = new QLabel(centralwidget);
        cardbase6->setObjectName(QString::fromUtf8("cardbase6"));
        cardbase6->setGeometry(QRect(220, 310, 40, 60));
        cardbase6->setPixmap(QPixmap(QString::fromUtf8("../../01 card.png")));
        cardbase6->setScaledContents(true);
        uprow = new QLabel(centralwidget);
        uprow->setObjectName(QString::fromUtf8("uprow"));
        uprow->setGeometry(QRect(40, 250, 40, 60));
        uprow->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow->setScaledContents(true);
        uprow_2 = new QLabel(centralwidget);
        uprow_2->setObjectName(QString::fromUtf8("uprow_2"));
        uprow_2->setGeometry(QRect(200, 250, 40, 60));
        uprow_2->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow_2->setScaledContents(true);
        uprow_3 = new QLabel(centralwidget);
        uprow_3->setObjectName(QString::fromUtf8("uprow_3"));
        uprow_3->setGeometry(QRect(160, 250, 40, 60));
        uprow_3->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow_3->setScaledContents(true);
        uprow_4 = new QLabel(centralwidget);
        uprow_4->setObjectName(QString::fromUtf8("uprow_4"));
        uprow_4->setGeometry(QRect(120, 250, 40, 60));
        uprow_4->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow_4->setScaledContents(true);
        uprow_5 = new QLabel(centralwidget);
        uprow_5->setObjectName(QString::fromUtf8("uprow_5"));
        uprow_5->setGeometry(QRect(80, 250, 40, 60));
        uprow_5->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow_5->setScaledContents(true);
        uprow2 = new QLabel(centralwidget);
        uprow2->setObjectName(QString::fromUtf8("uprow2"));
        uprow2->setGeometry(QRect(60, 190, 40, 60));
        uprow2->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow2->setScaledContents(true);
        uprow2_2 = new QLabel(centralwidget);
        uprow2_2->setObjectName(QString::fromUtf8("uprow2_2"));
        uprow2_2->setGeometry(QRect(100, 190, 40, 60));
        uprow2_2->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow2_2->setScaledContents(true);
        uprow2_3 = new QLabel(centralwidget);
        uprow2_3->setObjectName(QString::fromUtf8("uprow2_3"));
        uprow2_3->setGeometry(QRect(140, 190, 40, 60));
        uprow2_3->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow2_3->setScaledContents(true);
        uprow2_4 = new QLabel(centralwidget);
        uprow2_4->setObjectName(QString::fromUtf8("uprow2_4"));
        uprow2_4->setGeometry(QRect(180, 190, 40, 60));
        uprow2_4->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow2_4->setScaledContents(true);
        uprow3 = new QLabel(centralwidget);
        uprow3->setObjectName(QString::fromUtf8("uprow3"));
        uprow3->setGeometry(QRect(80, 130, 40, 60));
        uprow3->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow3->setScaledContents(true);
        uprow3_2 = new QLabel(centralwidget);
        uprow3_2->setObjectName(QString::fromUtf8("uprow3_2"));
        uprow3_2->setGeometry(QRect(120, 130, 40, 60));
        uprow3_2->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow3_2->setScaledContents(true);
        uprow3_3 = new QLabel(centralwidget);
        uprow3_3->setObjectName(QString::fromUtf8("uprow3_3"));
        uprow3_3->setGeometry(QRect(160, 130, 40, 60));
        uprow3_3->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow3_3->setScaledContents(true);
        uprow4 = new QLabel(centralwidget);
        uprow4->setObjectName(QString::fromUtf8("uprow4"));
        uprow4->setGeometry(QRect(100, 70, 40, 60));
        uprow4->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow4->setScaledContents(true);
        uprow4_2 = new QLabel(centralwidget);
        uprow4_2->setObjectName(QString::fromUtf8("uprow4_2"));
        uprow4_2->setGeometry(QRect(140, 70, 40, 60));
        uprow4_2->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow4_2->setScaledContents(true);
        uprow5 = new QLabel(centralwidget);
        uprow5->setObjectName(QString::fromUtf8("uprow5"));
        uprow5->setGeometry(QRect(120, 10, 40, 60));
        uprow5->setPixmap(QPixmap(QString::fromUtf8("../../placeholder.png")));
        uprow5->setScaledContents(true);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(160, 10, 40, 60));
        pushButton->setAutoFillBackground(false);
        pushButton->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"border: 0;"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../placeholder.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon);
        pushButton->setIconSize(QSize(40, 60));
        pushButton->setAutoRepeat(false);
        pushButton->setFlat(true);
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(760, 70, 161, 191));
        pushButton_2->setStyleSheet(QString::fromUtf8("border: 0px;\n"
"background: transparent;l"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../card.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_2->setIcon(icon1);
        pushButton_2->setIconSize(QSize(161, 191));
        pushButton_2->setFlat(true);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1209, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QString());
        cardbase1->setText(QString());
        cardbase2->setText(QString());
        cardbase3->setText(QString());
        cardbase4->setText(QString());
        cardbase5->setText(QString());
        cardbase6->setText(QString());
        uprow->setText(QString());
        uprow_2->setText(QString());
        uprow_3->setText(QString());
        uprow_4->setText(QString());
        uprow_5->setText(QString());
        uprow2->setText(QString());
        uprow2_2->setText(QString());
        uprow2_3->setText(QString());
        uprow2_4->setText(QString());
        uprow3->setText(QString());
        uprow3_2->setText(QString());
        uprow3_3->setText(QString());
        uprow4->setText(QString());
        uprow4_2->setText(QString());
        uprow5->setText(QString());
        pushButton->setText(QString());
        pushButton_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
